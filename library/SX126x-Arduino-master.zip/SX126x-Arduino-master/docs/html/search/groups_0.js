var searchData=
[
  ['common_20region_20implementation_4342',['Common region implementation',['../group___r_e_g_i_o_n_c_o_m_m_o_n.html',1,'']]]
];
