var searchData=
[
  ['use_5fdcdc_3928',['USE_DCDC',['../sx126x_8h.html#a3b5b9328caadebb2acab3c5d7faefafca7c2111b4c52b035f17581c58fa6e719d',1,'sx126x.h']]],
  ['use_5fldo_3929',['USE_LDO',['../sx126x_8h.html#a3b5b9328caadebb2acab3c5d7faefafca986dd845c547cb83c3d1b334714e94be',1,'sx126x.h']]]
];
